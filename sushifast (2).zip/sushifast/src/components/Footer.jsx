export default function Footer() {
  return (
    <footer className="text-white py-3 text-center custom-bg">
      <p>SushiFast © 2025 — TP React</p>
      <p>Nicolas Rannou TD2 TPC</p>
    </footer>
  );
}
